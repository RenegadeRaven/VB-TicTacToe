﻿Public Class Form1
    Dim dir As String = My.Application.Info.DirectoryPath
    Dim web As New System.Net.WebClient
    Dim prog As String = dir & "\TicTacToe.exe"
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        For Each proc As Process In Process.GetProcesses
            If proc.ProcessName = "TicTacToe" Then
                proc.Kill()
                getUpdate()
            Else
                getUpdate()
            End If
        Next
    End Sub
    Public Sub getUpdate()
        If System.IO.File.Exists(prog) Then
            System.IO.File.Delete(prog)
            web.DownloadFileAsync(New Uri("https://github.com/PlasticJustice/VB-TicTacToe/raw/master/TicTacToe/bin/Release/TicTacToe.exe"), prog)
            Timer1.Start()
        Else
            web.DownloadFileAsync(New Uri("https://github.com/PlasticJustice/VB-TicTacToe/raw/master/TicTacToe/bin/Release/TicTacToe.exe"), prog)
            Timer1.Start()
        End If
    End Sub
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Process.Start(prog)
        Application.Exit()
    End Sub
End Class